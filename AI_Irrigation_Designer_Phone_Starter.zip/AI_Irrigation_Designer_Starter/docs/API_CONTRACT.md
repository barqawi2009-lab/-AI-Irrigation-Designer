# Initial API contract

- `GET /health`: backend health.
- `POST /hydraulics/darcy-weisbach`: preliminary straight-pipe friction estimate.

Example JSON:
```json
{
  "flow_m3_h": 2.5,
  "internal_diameter_mm": 40,
  "length_m": 80,
  "roughness_mm": 0.0015,
  "water_temperature_c": 20
}
```

Planned endpoints:
- `POST /projects`
- `GET /projects/{project_id}`
- `POST /projects/{project_id}/site-plan`
- `POST /projects/{project_id}/zones`
- `POST /projects/{project_id}/design/draft`
- `POST /projects/{project_id}/hydraulic-check`
- `GET /projects/{project_id}/reports/boq`
