package com.example.irrigationdesigner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IrrigationDesignerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IrrigationDesignerApp() {
    var arabic by remember { mutableStateOf(true) }
    var projectName by remember { mutableStateOf("") }
    var projectType by remember { mutableStateOf("Garden / حديقة") }
    var irrigationType by remember { mutableStateOf("Mixed / مختلط") }
    val direction = if (arabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text(if (arabic) "مصمم شبكات الري الذكي" else "AI Irrigation Designer") },
                        actions = {
                            TextButton(onClick = { arabic = !arabic }) {
                                Text(if (arabic) "EN" else "عربي")
                            }
                        }
                    )
                }
            ) { padding ->
                Column(
                    modifier = Modifier.padding(padding).fillMaxSize()
                        .verticalScroll(rememberScrollState()).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        if (arabic) "مرحباً بك في مساعد تصميم شبكات الري" else "Welcome to your irrigation design assistant",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(if (arabic) "أنشئ مشروعاً جديداً وابدأ بإدخال بيانات الموقع." else "Create a project and enter site information.")
                    OutlinedTextField(
                        value = projectName,
                        onValueChange = { projectName = it },
                        label = { Text(if (arabic) "اسم المشروع" else "Project name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(if (arabic) "نوع المشروع" else "Project type", fontWeight = FontWeight.SemiBold)
                    listOf("Garden / حديقة", "Farm / مزرعة", "Sports field / ملعب", "Large landscape / موقع كبير").forEach {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = projectType == it, onClick = { projectType = it })
                            Text(it)
                        }
                    }
                    Text(if (arabic) "نظام الري" else "Irrigation method", fontWeight = FontWeight.SemiBold)
                    listOf("Drip / تنقيط", "Sprinkler / رش", "Mixed / مختلط").forEach {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = irrigationType == it, onClick = { irrigationType = it })
                            Text(it)
                        }
                    }
                    Button(
                        onClick = { /* Next: persist project and open site data workflow */ },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = projectName.isNotBlank()
                    ) { Text(if (arabic) "إنشاء المشروع" else "Create project") }
                    OutlinedButton(
                        onClick = { /* Next: Android document picker */ },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (arabic) "رفع مخطط الموقع — قريباً" else "Upload site plan — coming next") }
                    Text(
                        if (arabic) "نسخة تطوير أولية. يجب مراجعة الحسابات هندسياً قبل التنفيذ."
                        else "Development preview. Engineering verification is required before construction.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}
