# AI Irrigation Designer — Android Starter

Initial scaffold for an independent bilingual Android irrigation-design app.

## Stack
- Android: Kotlin + Jetpack Compose
- Backend: Python + FastAPI
- Local storage: Room/SQLite (dependency included)
- Hydraulic starter: Darcy-Weisbach straight-pipe estimate
- Languages: Arabic RTL / English LTR

## Run backend
```bash
cd backend
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Open `android/` in Android Studio, sync Gradle, and run on an Android emulator/device.

Emulator host URL is normally `http://10.0.2.2:8000/`. For a physical phone, use the computer's LAN IP.

## Important
This is a starter scaffold, not a production engineering application. The hydraulic endpoint estimates friction loss in a straight pipe only. It does not include fittings, valves, elevation, emitters, pump curves, or network balancing. Do not use it as a construction design without validated equipment data, full network analysis, testing, and professional review.

## Build APK using only your phone
1. Create a GitHub account and a new repository.
2. Upload the contents of this project ZIP to the repository using the GitHub mobile website.
3. Open the repository's Actions tab.
4. Select `Build Android APK` and tap `Run workflow` (or edit a file and push a commit).
5. When the workflow finishes, open the run and download the `ai-irrigation-designer-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`.
   Android may ask you to allow installation from your browser or file manager.

The APK workflow builds the Android starter app in GitHub's cloud. The Python backend and secure AI service are separate deployment steps.
