import math

def darcy_weisbach(flow_m3_h, diameter_mm, length_m, roughness_mm=0.0015, temperature_c=20.0):
    # Preliminary straight-pipe friction estimate only.
    if min(flow_m3_h, diameter_mm, length_m) <= 0:
        raise ValueError("Flow, diameter and length must be positive.")
    q = flow_m3_h / 3600.0
    d = diameter_mm / 1000.0
    eps = roughness_mm / 1000.0
    area = math.pi * d * d / 4.0
    velocity = q / area

    # Approximate kinematic viscosity of water (m2/s), nearest 10 C reference.
    nu_table = [(0, 1.792e-6), (10, 1.307e-6), (20, 1.004e-6),
                (30, 0.801e-6), (40, 0.658e-6), (50, 0.554e-6)]
    nu = min(nu_table, key=lambda p: abs(p[0] - temperature_c))[1]
    reynolds = velocity * d / nu

    if reynolds < 2300:
        friction_factor = 64.0 / reynolds
        regime = "laminar"
    else:
        friction_factor = 0.25 / (math.log10(eps / (3.7 * d) + 5.74 / (reynolds ** 0.9)) ** 2)
        regime = "turbulent"

    head_loss_m = friction_factor * (length_m / d) * (velocity ** 2 / (2 * 9.80665))
    pressure_loss_bar = head_loss_m * 0.0980665

    return {
        "flow_m3_h": round(flow_m3_h, 4),
        "internal_diameter_mm": round(diameter_mm, 3),
        "length_m": round(length_m, 3),
        "velocity_m_s": round(velocity, 4),
        "reynolds_number": round(reynolds, 1),
        "flow_regime": regime,
        "darcy_friction_factor": round(friction_factor, 6),
        "friction_head_loss_m": round(head_loss_m, 4),
        "friction_pressure_loss_bar": round(pressure_loss_bar, 5),
        "warning": "Straight-pipe estimate only; excludes fittings, valves, elevation and network interactions."
    }
