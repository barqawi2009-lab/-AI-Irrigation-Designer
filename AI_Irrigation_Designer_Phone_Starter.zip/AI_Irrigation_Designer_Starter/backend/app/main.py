from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .hydraulics import darcy_weisbach

app = FastAPI(title="AI Irrigation Designer API", version="0.1.0")

class PipeCalculationRequest(BaseModel):
    flow_m3_h: float = Field(gt=0)
    internal_diameter_mm: float = Field(gt=0)
    length_m: float = Field(gt=0)
    roughness_mm: float = Field(default=0.0015, ge=0)
    water_temperature_c: float = Field(default=20, ge=0, le=50)

@app.get("/health")
def health():
    return {"status": "ok", "service": "AI Irrigation Designer API"}

@app.post("/hydraulics/darcy-weisbach")
def calculate_pipe_loss(payload: PipeCalculationRequest):
    try:
        return darcy_weisbach(
            flow_m3_h=payload.flow_m3_h,
            diameter_mm=payload.internal_diameter_mm,
            length_m=payload.length_m,
            roughness_mm=payload.roughness_mm,
            temperature_c=payload.water_temperature_c,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
